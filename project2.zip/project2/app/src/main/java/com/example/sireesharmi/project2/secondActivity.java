package com.example.sireesharmi.project2;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Sireesharmi on 03-08-2016.
 */
public class secondActivity extends Activity {

    EditText editText;
    Button save;
    TextView textView;
    Context context;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        editText=(EditText)findViewById(R.id.edittext);
        save=(Button)findViewById(R.id.save);
        textView=(TextView)findViewById(R.id.textView);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=editText.getText().toString();
                NewDataBase newDataBase=new NewDataBase(context.getApplicationContext());
                db=newDataBase.getWritableDatabase();
                newDataBase.addEvent(name,db);
                Toast.makeText(secondActivity.this,"Saved",Toast.LENGTH_LONG).show();
                newDataBase.close();
            }
        });

    }
}
