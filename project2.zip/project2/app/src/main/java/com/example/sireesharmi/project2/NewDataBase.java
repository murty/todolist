package com.example.sireesharmi.project2;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Sireesharmi on 03-08-2016.
 */
public class NewDataBase extends SQLiteOpenHelper {

    private static final String DB_name="name";
    private static final int DB_VER=1;
    private static final String TAb_NAME="tab_name";
    private static final String Item_name="name_item";

    public NewDataBase(Context context){
        super(context,DB_name,null,DB_VER);
        Log.e("DATAbASE OPERATIONS","database created");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String Query="CREATE TABLE "+TAb_NAME+"("+Item_name+" TEXT);";
        db.execSQL(Query);
        Log.e("DATABASE OPERATIONS","table created");
    }

    public void addEvent(String name,SQLiteDatabase db)
    {
        ContentValues contentValues=new ContentValues();
        contentValues.put(Item_name,name);
        db.insert(TAb_NAME,null,contentValues);
        Log.e("DATABASE OPERATIONS","row inserted");
        db.close();
    }
    public Cursor show(SQLiteDatabase db)
    {
        Cursor cursor;
        String[] column={Item_name};
        cursor=db.query(TAb_NAME,column,null,null,null,null,null);
        return cursor;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
