package com.example.sireesharmi.project2;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Sireesharmi on 03-08-2016.
 */
public class thirdActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third_layout);
    }
}
