package com.example.sireesharmi.project2;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Context;

public class MainActivity extends AppCompatActivity {

    Button add;
    Button view;
    Context context;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add=(Button)findViewById(R.id.add);
        view=(Button)findViewById(R.id.view);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,secondActivity.class);
                startActivity(intent);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NewDataBase newDataBase=new NewDataBase(context.getApplicationContext());
                //NewDataBase newDataBase=new NewDataBase(context);
                db=newDataBase.getReadableDatabase();
                newDataBase.show(db);
                newDataBase.close();
                Intent intent=new Intent(MainActivity.this,thirdActivity.class);
                startActivity(intent);
            }
        });
    }
}
